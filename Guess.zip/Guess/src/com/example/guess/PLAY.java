package com.example.guess;

import java.util.ArrayList;
import java.util.Random;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class PLAY extends Activity {

	ArrayAdapter<String> adapter;
	int number[];
	int gnum;
	int[] arrgnum;
	int cow, bull;
	ListView listView;
	int no_try;

	private static int n;
	private santimer timer;
	private Boolean flag = false;
	private final long startTime = 5000000;
	private final long interval = 1000;

	private long timeElapsed;
String randnum ;
	String gString = "hello";
	protected String result = "";
	int num;
	private InterstitialAd interad ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		super.onCreate(savedInstanceState);
		setContentView(R.layout.play);
		no_try = 0;

		AdView adView = (AdView) findViewById(R.id.adView);
		AdRequest adRequest = new AdRequest.Builder().build();

		//adView.loadAd(adRequest);

		timer = new santimer(startTime, interval);
		timer.start();
		adapter = new ArrayAdapter<String>(this, R.layout.list);
		listView = (ListView) findViewById(R.id.listview);
		listView.setAdapter(adapter);
		Random r = new Random();

		try {
			Bundle b = getIntent().getExtras();
			n = b.getInt("level");
		} catch (Exception e) {
			e.printStackTrace();
		}

		int size;
		int digit = 0;
		
		switch (n) {
		case 4:
			size = four.length;
			
			randnum = four[r.nextInt(size)] ;
			digit = Integer.valueOf(randnum);
			break;
		case 5:
			size = five.length;
			randnum = four[r.nextInt(size)] ;
			digit = Integer.valueOf(randnum);
			break;
		case 6:
			size = six.length;
			randnum = four[r.nextInt(size)] ;
			digit = Integer.valueOf(randnum);
		default:

		}
		num = digit;
		number = new int[n];
		for (int i = 0; i < n; i++) {
			number[n - 1 - i] = digit % 10;
			digit = digit / 10;
		}

		fragment1 f = new fragment1();
		FragmentManager fm = getFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();
		Bundle bas = new Bundle();
		bas.putInt("key", n);
		f.setArguments(bas);
		ft.replace(R.id.ll, f);
		ft.commit();

	}

	public void c(View view) {

		try {
			no_try++;
			fragment1 f1 = (fragment1) getFragmentManager().findFragmentById(
					R.id.ll);
			View frag = f1.getView();
			EditText t = (EditText) frag.findViewById(R.id.text);

			gString = t.getText().toString();

			cow = 0;
			bull = 0;
			if (gString.equals("") || gString.length() != n) {
				Toast.makeText(getBaseContext(), "PLZ enter desired number",
						Toast.LENGTH_SHORT).show();
			} else {
				gnum = Integer.valueOf(gString);
				arrgnum = new int[n];
				int d = gnum;
				int i = n - 1, j;
				while (i >= 0) {
					arrgnum[i--] = d % 10;
					d = d / 10;
				}
				int[] arr = new int[10];
				for (i = 0; i < 10; i++) {
					arr[i] = 0;
				}

				for (i = 0; i < n; i++) {
					if (arrgnum[i] == number[i]) {
						cow++;
						arr[arrgnum[i]] = 1;
					}
				}
				for (i = 0; i < n; i++) {
					for (j = 0; j < n; j++) {
						if (arr[arrgnum[i]] == 0 && arrgnum[i] == number[j]) {
							if (i == j) {
								continue;
							} else {
								bull++;
								arr[arrgnum[i]] = 1;
							}
						}
					}
				}

				result = cow + "A" + bull + "B";
				if (cow == n) {
					timer.cancel();
					ContentValues values = new ContentValues();
					values.put(Database.score.SCORE, no_try);
					values.put(Database.score.TIME, timeElapsed / 1000);

					Uri uri = getContentResolver().insert(Database.Contenturi,
							values);
					Vibrator v = (Vibrator) this
							.getSystemService(Context.VIBRATOR_SERVICE);
					v.vibrate(500);

					Bundle b = new Bundle();
					b.putInt("try", no_try);
					b.putString("num",randnum);
					b.putLong("time", timeElapsed);
					Intent in = new Intent(this, Finish.class);
					in.putExtras(b);
					startActivity(in);

				} else {
					fragment2 f = new fragment2();

					FragmentManager fm = getFragmentManager();
					FragmentTransaction ft = fm.beginTransaction();
					Bundle b = new Bundle();
					b.putString("result", result);
					f.setArguments(b);
					ft.replace(R.id.ll, f);

					ft.commit();

					adapter.insert(gString + "   ----->   " + result, 0);

					Handler handler = new Handler();
					handler.postDelayed(new Runnable() {
						@Override
						public void run() {

							fragment1 f = new fragment1();
							FragmentManager fm = getFragmentManager();
							FragmentTransaction ft = fm.beginTransaction();
							Bundle bas = new Bundle();
							bas.putInt("key", n);
							f.setArguments(bas);
							ft.replace(R.id.ll, f);

							ft.commit();

						}
					}, 1500);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

	private String four[] = { "0123", "0124", "0125", "0126", "0127", "0128",
			"0129", "2130", "2140", "2150", "2160", "2170", "2180", "2190",
			"3120", "3124", "3125", "3126", "3127", "3128", "3129", "4120",
			"4130", "4150", "4160", "4170", "4180", "4190", "5102", "5103",
			"5104", "5106", "5107", "5180", "2346"

	};
	private String five[] = { "01234", "31274", "31285", "31295", "41205",
			"41305", "41502", "41609", "41706", "41806", "41908", "51028",
			"51032", "51049", "51069", "51079", "51809" };
	private String six[] = { "012456", "456789", "312745", "312845", "312954",
			"412053", "413065", "415036", "416038", "417083", "418037",
			"419037", "510236", "510326", "510496", "510697", "510798",
			"518092" };

	public void q(View v) {

	}

	private class santimer extends CountDownTimer {

		public santimer(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
			// TODO Auto-generated constructor stub

		}

		@Override
		public void onFinish() {
			// TODO Auto-generated method stub
		}

		@Override
		public void onTick(long millisUntilFinished) {
			// TODO Auto-generated method stub

			timeElapsed = startTime - millisUntilFinished;

		}

	}

}
