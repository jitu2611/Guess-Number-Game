package com.example.guess;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Finish extends Activity {

	Button again, back, exit;
	TextView tv,time;
	LinearLayout l;
	int scale;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.finish);
		scale = getResources().getDisplayMetrics().DENSITY_LOW;

		tv = (TextView) findViewById(R.id.finish);
		time = (TextView)findViewById(R.id.time) ;
		l = (LinearLayout) findViewById(R.id.fll);

		Bundle b = getIntent().getExtras();
		int no_try = b.getInt("try");
		long t = b.getLong("time");
		String num = b.getString("num") ;
		t=t/1000 ;
		long min , sec,hr ;
		hr = t/3600 ;
		t = t - hr*3600 ;
		min = t/60 ;
		
		sec = t - min*60;
		if(hr!=0){
			time.setText(hr+":"+min+":"+sec) ;
		}
		else if(hr==0 && min!=0 && min>9){
			{
				if(sec>9){
					time.setText("00:"+min+":"+sec) ;
				}
				else{
					time.setText("00:"+min+":0"+sec) ;
				}
			}
		}else if(hr==0 && min!=0){
			if(sec>9){
				time.setText("00:0"+min+":"+sec) ;
			}
			else{
				time.setText("00:0"+min+":0"+sec) ;
			}
		}
		else if(min ==0 &&sec>9){
			time.setText("00:00:"+sec) ;
		}else{
			time.setText("00:00:0"+sec) ;
		}
		
		if(no_try==1){
			tv.setText("You Correctly Guessed The Number "+num+" In " + no_try
					+ " Try");
		}else{
			tv.setText("You Correctly Guessed The Number "+num+ " In " + no_try
					+ " Tries");
		}
		
	}

	public void tryagain(View v) {
		
		Intent i = new Intent(this, PLAY.class);
		startActivity(i);
	}

	public void backtomenu(View v) {
		finish();
	}

	public void quit(View v) {
		moveTaskToBack(true);
		Finish.this.finish();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
}
