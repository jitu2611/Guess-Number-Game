package com.example.guess;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class fragment2 extends Fragment {
	String m;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View myInflatedView = inflater.inflate(R.layout.f2, container, false);
		Bundle extras = getArguments();
		m = extras.getString("result");
		// Set the Text to try this out
		TextView t = (TextView) myInflatedView.findViewById(R.id.textView1);
		t.setText(m);

		return myInflatedView;

	}

}
