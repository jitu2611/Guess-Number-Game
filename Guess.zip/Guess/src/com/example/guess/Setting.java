package com.example.guess;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Setting extends Activity {
	int level = 4;
	TextView tv;
	RadioGroup rg,rgs;
	RadioButton rb,rb1,rb2,rb3,rs1,rs2;
	boolean Sound=true ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting);
		tv = (TextView) findViewById(R.id.lev);
		rg = (RadioGroup) findViewById(R.id.radiogroup);
		rgs = (RadioGroup)findViewById(R.id.radiogroupsound) ;
		rb1 = (RadioButton)findViewById(R.id.b1) ;
		rb2 = (RadioButton)findViewById(R.id.b2) ;
		rb3 = (RadioButton)findViewById(R.id.b3) ;
		rs2 = (RadioButton)findViewById(R.id.s2) ;
		rs1 = (RadioButton)findViewById(R.id.s1) ;
		
		
		Bundle b = getIntent().getExtras() ;
		int n = b.getInt("level") ;
		Sound = b.getBoolean("sound") ;
		if(Sound){
			rs1.setChecked(true) ;
		}else{
			rs2.setChecked(true) ;
		}
		switch(n){
		case 4:
			rb1.setChecked(true) ;
			
			  
			break ;
		case 5:
			rb2.setChecked(true) ;
			break ;
		case 6:
			rb3.setChecked(true) ;
			break ;
		}
		

	}

	public void save(View v) {

		int selected = rg.getCheckedRadioButtonId() ;
		int s = rgs.getCheckedRadioButtonId() ;
		rb = (RadioButton)findViewById(selected) ;
		RadioButton rbs = (RadioButton)findViewById(s) ;
		String sou = (String) rbs.getText() ;
		
		String a = (String) rb.getText() ;
		level = Integer.valueOf(a) ;
		Bundle b = new Bundle();
		b.putInt("level", level);
		b.putString("sound", sou) ;
		Intent i = new Intent();
		i.putExtras(b);
		setResult(RESULT_OK, i);
		finish();
	}

}
