package com.example.guess;

import java.util.ArrayList;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class score extends Activity {
	ListView lv;

	ArrayAdapter<String> adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.score);

		Cursor c = getContentResolver().query(Database.Contenturi, null, null,
				null, Database.score.TIME);
		adapter = new ArrayAdapter<String>(this, R.layout.list);
		lv = (ListView) findViewById(R.id.scorelist);
		lv.setAdapter(adapter);
		
         int i =0 ;
		if (c.moveToFirst()) {
			do {
				 String s = c.getString(c.getColumnIndex(Database.score.TIME)) + " sec  ( "+c.getString(c.getColumnIndex(Database.score.SCORE))+" )" ;
				adapter.insert(s,i++) ;
						
				        
			} while (c.moveToNext() && i<10);
		}
	}

}
