package com.example.guess;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

public class fragment1 extends Fragment {
	EditText t;
 int max =0 ;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		View myInflatedView = inflater.inflate(R.layout.f1, container, false);
		 
		 try{
			 Bundle extras = getArguments() ;
			  max =extras.getInt("key") ;
		 }catch(Exception e)
		 {
			 e.printStackTrace() ;
		 }
	     
		t  = (EditText)myInflatedView.findViewById(R.id.text) ;
		InputFilter[] filters = new InputFilter[1];
		filters[0] = new InputFilter.LengthFilter(max);
		t.setFilters(filters);
		
		

		return myInflatedView;

	}

}
