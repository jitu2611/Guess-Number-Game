package com.example.guess;

import com.google.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {
	Button play, setting, highscore;
	int n = 4;
	boolean SoundEnabled = true ;

	Thread t;
	private String tag = "MainActivity";
	private MediaPlayer mp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Log.i(tag, "OnCreate");

		FrameLayout img = (FrameLayout) findViewById(R.id.fl);
		((AnimationDrawable) img.getBackground()).start();
		play = (Button) findViewById(R.id.play);
		setting = (Button) findViewById(R.id.setting);
		highscore = (Button) findViewById(R.id.highscore);
		int scale = getResources().getDisplayMetrics().DENSITY_LOW;
		play.setTextSize(scale / 3);
		setting.setTextSize(scale / 3);
		highscore.setTextSize(scale / 3);

	}

	public void play(View view) {
		
		Bundle b = new Bundle();
		b.putInt("level", n);
		Toast.makeText(this, "PLAY", Toast.LENGTH_SHORT).show();
		Intent i = new Intent(MainActivity.this, PLAY.class);
		i.putExtras(b);
		startActivity(i);
	}

	public void highscore(View v) {
		Intent i = new Intent(this, score.class);
		startActivity(i);
	}

	public void setting(View v) {
		Bundle b = new Bundle();
		b.putInt("level", n);
		b.putBoolean("sound", SoundEnabled) ;
		Intent i = new Intent(this, Setting.class);
		i.putExtras(b);
		startActivityForResult(i, 0);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			Bundle b = data.getExtras();
			n = b.getInt("level");
			String sound = b.getString("sound") ;
			if(sound.contentEquals("Yes")) {
				SoundEnabled = true ;
			}else{
				SoundEnabled = false ;
			}
			Toast.makeText(this, "" + n, Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onRestart();
		
		 mp = MediaPlayer.create(this, R.raw.gamestartup);
		 if(SoundEnabled){
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				mp.start();
			}
		});
		t.start();

		Log.i(tag, "RESTART");
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if(mp.isPlaying()){
		mp.pause();
		mp.release() ;
		}
	}

	

	
}
